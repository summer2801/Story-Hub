import React, { Component } from 'react';
import { Button, View, Text, TouchableOpacity,StyleSheet } from 'react-native';

class AppHeader extends React.Component{
  render(){
    return(
      <View style={styles.textContainer}>
      <Text style ={styles.text}>📘Story Hub📘</Text>
      </View>
    )
  }
}
const styles = StyleSheet.create({
 textContainer:{
   backgroundColor:"pink",
   
 } ,

 text:{
    color : "black",
    fontSize : 40,
    fontWeight: 'bold',
    textAlign :"center",
    height: 60,
    marginTop: 10,
    fontFamily:"French Script MT"
 }
})

export default AppHeader;