import firebase from "firebase"
require("@firebase/firestore")
  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyB2QzRT8tVLNr3q3mfPFEf76p64Iv2Kew8",
    authDomain: "story-hub-98c79.firebaseapp.com",
    databaseURL: "https://story-hub-98c79-default-rtdb.firebaseio.com",
    projectId: "story-hub-98c79",
    storageBucket: "story-hub-98c79.appspot.com",
    messagingSenderId: "265071553949",
    appId: "1:265071553949:web:5fd19946f508a07773d374"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

export default firebase.firestore()